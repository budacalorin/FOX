<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Lava_Cave" tilewidth="32" tileheight="32" tilecount="105" columns="15">
 <image source="../../../../Users/Lorin/Downloads/Lava_Cave.png" width="505" height="229"/>
</tileset>
