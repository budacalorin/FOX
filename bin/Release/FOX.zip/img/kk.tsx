<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="kk" tilewidth="1366" tileheight="1601" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="256" height="300" source="../../../../Users/Lorin/Downloads/untitled folder/exterior-parallaxBG1.png"/>
 </tile>
 <tile id="1">
  <image width="1366" height="1601" source="../../../../Users/Lorin/Downloads/untitled folder/exterior-parallaxBG1.png"/>
 </tile>
</tileset>
