<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="scifi_platformTiles_32x32_1" tilewidth="32" tileheight="32" tilecount="805" columns="35">
 <image source="scifi_platformTiles_32x32_1.png" width="1120" height="736"/>
 <terraintypes>
  <terrain name="New Terrain" tile="339"/>
 </terraintypes>
 <tile id="303" terrain=",,,0"/>
 <tile id="304" terrain=",,0,0"/>
 <tile id="305" terrain=",,0,"/>
 <tile id="338" terrain=",0,,0"/>
 <tile id="339" terrain="0,0,0,0"/>
 <tile id="340" terrain="0,,0,"/>
 <tile id="373" terrain=",0,,"/>
 <tile id="374" terrain="0,0,,"/>
 <tile id="375" terrain="0,,,"/>
</tileset>
