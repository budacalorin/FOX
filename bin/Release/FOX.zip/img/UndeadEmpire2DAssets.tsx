<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="UndeadEmpire2DAssets" tilewidth="32" tileheight="32" tilecount="252" columns="18">
 <image source="UndeadEmpire2DAssets.png" width="576" height="448"/>
</tileset>
