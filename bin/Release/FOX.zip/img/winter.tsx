<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="winter" tilewidth="32" tileheight="32" tilecount="7" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="Free Platform Game Assets/Platform Game Assets/Tiles/png/512x512/Dirt.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="Free Platform Game Assets/Update 1.9/New Tiles (2D view)/Winter/512x512/Grass.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="Free Platform Game Assets/Update 1.9/New Tiles (2D view)/Winter/512x512/GrassMid.png"/>
 </tile>
 <tile id="26">
  <image width="32" height="32" source="Free Platform Game Assets/Update 1.9/New Tiles (2D view)/Winter/512x512/GrassRight.png"/>
 </tile>
 <tile id="27">
  <image width="32" height="32" source="Free Platform Game Assets/Update 1.9/New Tiles (2D view)/Winter/512x512/DirtRight.png"/>
 </tile>
 <tile id="28">
  <image width="32" height="32" source="Free Platform Game Assets/Update 1.9/New Tiles (2D view)/Winter/512x512/GrassLeft.png"/>
 </tile>
 <tile id="29">
  <image width="32" height="32" source="Free Platform Game Assets/Update 1.9/New Tiles (2D view)/Winter/512x512/DirtLeft.png"/>
 </tile>
</tileset>
